(()=>{var e={};e.id=374,e.ids=[374,888,660],e.modules={8832:(e,t,r)=>{"use strict";r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{config:()=>b,default:()=>u,getServerSideProps:()=>m,getStaticPaths:()=>p,getStaticProps:()=>x,reportWebVitals:()=>g,routeModule:()=>S,unstable_getServerProps:()=>j,unstable_getServerSideProps:()=>w,unstable_getStaticParams:()=>v,unstable_getStaticPaths:()=>y,unstable_getStaticProps:()=>f});var i=r(7093),s=r(5244),n=r(1323),o=r(2899),l=r.n(o),c=r(9413),d=r(7825),h=e([c,d]);[c,d]=h.then?(await h)():h;let u=(0,n.l)(d,"default"),x=(0,n.l)(d,"getStaticProps"),p=(0,n.l)(d,"getStaticPaths"),m=(0,n.l)(d,"getServerSideProps"),b=(0,n.l)(d,"config"),g=(0,n.l)(d,"reportWebVitals"),f=(0,n.l)(d,"unstable_getStaticProps"),y=(0,n.l)(d,"unstable_getStaticPaths"),v=(0,n.l)(d,"unstable_getStaticParams"),j=(0,n.l)(d,"unstable_getServerProps"),w=(0,n.l)(d,"unstable_getServerSideProps"),S=new i.PagesRouteModule({definition:{kind:s.x.PAGES,page:"/tools/[id]",pathname:"/tools/[id]",bundlePath:"",filename:""},components:{App:c.default,Document:l()},userland:d});a()}catch(e){a(e)}})},6137:(e,t,r)=>{"use strict";r.a(e,async(e,a)=>{try{r.d(t,{Z:()=>d});var i=r(997),s=r(2210),n=r(1163),o=r(1664),l=r.n(o),c=e([s]);s=(c.then?(await c)():c)[0];let d=({children:e})=>{let t=(0,n.useRouter)(),r=(0,s.useBreakpointValue)({base:!0,md:!1}),a=[{label:"首页",href:"/",icon:"\uD83C\uDFE0"},{label:"发现",href:"/discover",icon:"\uD83D\uDD0D"},{label:"更新",href:"/changelog",icon:"\uD83D\uDCCB"},{label:"收藏",href:"/favorites",icon:"⭐"},{label:"我的",href:"/profile",icon:"\uD83D\uDC64"}];return(0,i.jsxs)(s.Box,{minH:"100vh",position:"relative",pb:r?"60px":0,children:[i.jsx(s.Box,{bg:"white",borderBottom:"1px solid",borderColor:"brand.gray.200",position:"sticky",top:0,zIndex:1e3,children:i.jsx(s.Container,{maxW:"var(--max-width)",py:3,children:(0,i.jsxs)(s.Flex,{justify:"space-between",align:"center",children:[i.jsx(l(),{href:"/",passHref:!0,children:i.jsx(s.Text,{fontSize:"xl",fontWeight:"bold",color:"brand.primary",children:"Tools Hub"})}),i.jsx(s.Flex,{gap:4,className:"desktop-only",children:a.map(e=>i.jsx(l(),{href:e.href,passHref:!0,children:i.jsx(s.Text,{cursor:"pointer",color:t.pathname===e.href?"brand.primary":"brand.gray.600",_hover:{color:"brand.primary"},children:e.label})},e.href))})]})})}),i.jsx(s.Container,{maxW:"var(--max-width)",py:4,children:e}),r&&i.jsx(s.Box,{position:"fixed",bottom:0,left:0,right:0,bg:"white",borderTop:"1px solid",borderColor:"brand.gray.200",py:2,children:i.jsx(s.Flex,{justify:"space-around",align:"center",children:a.map(e=>i.jsx(l(),{href:e.href,passHref:!0,children:(0,i.jsxs)(s.Flex,{direction:"column",align:"center",color:t.pathname===e.href?"brand.primary":"brand.gray.600",children:[i.jsx(s.Text,{fontSize:"xl",children:e.icon}),i.jsx(s.Text,{fontSize:"xs",children:e.label})]})},e.href))})})]})};a()}catch(e){a(e)}})},4184:(e,t,r)=>{"use strict";r.a(e,async(e,a)=>{try{r.d(t,{Z:()=>n});var i=r(2210),s=e([i]);i=(s.then?(await s)():s)[0];let n=(0,i.extendTheme)({colors:{brand:{primary:"#0020B0",bg:"#F9FAFB",text:"#1F2937",gray:{100:"#F3F4F6",200:"#E5E7EB",300:"#D1D5DB",400:"#9CA3AF",500:"#6B7280",600:"#4B5563",700:"#374151"}}},fonts:{heading:"var(--font-roboto)",body:"var(--font-roboto)"},styles:{global:{body:{bg:"brand.bg",color:"brand.text"}}},components:{Button:{baseStyle:{fontWeight:"medium"},variants:{solid:{bg:"brand.primary",color:"white",_hover:{bg:"brand.primary",opacity:.9}},outline:{borderColor:"brand.primary",color:"brand.primary"}}}}});a()}catch(e){a(e)}})},418:(e,t,r)=>{"use strict";r.a(e,async(e,a)=>{try{r.d(t,{rj:()=>n,uL:()=>o});var i=r(3806),s=e([i]);let n=[(i=(s.then?(await s)():s)[0]).v,{info:{id:"empty-tool",name:"空白工具",description:"这是一个用于调试的空白工具",icon:"\uD83D\uDD27",category:"code",tags:["demo","debug"]},routes:{index:"/tools/empty-tool"}}],o=e=>n.find(t=>t.info.id===e);a()}catch(e){a(e)}})},9413:(e,t,r)=>{"use strict";r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{default:()=>l});var i=r(997),s=r(2210),n=r(4184);r(6961),r(2744);var o=e([s,n]);function l({Component:e,pageProps:t}){return i.jsx(s.ChakraProvider,{theme:n.Z,children:i.jsx(e,{...t})})}[s,n]=o.then?(await o)():o,a()}catch(e){a(e)}})},7825:(e,t,r)=>{"use strict";r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{default:()=>d,getStaticPaths:()=>h,getStaticProps:()=>u});var i=r(997),s=r(1163),n=r(2210),o=r(6137),l=r(418),c=e([n,o,l]);function d({tool:e}){return(0,s.useRouter)().isFallback?i.jsx(o.Z,{children:i.jsx(n.Container,{maxW:"var(--max-width)",py:8,children:i.jsx(n.Text,{children:"加载中..."})})}):e?i.jsx(o.Z,{children:i.jsx(n.Container,{maxW:"var(--max-width)",py:8,children:(0,i.jsxs)(n.Box,{bg:"white",p:6,borderRadius:"16px",boxShadow:"sm",children:[(0,i.jsxs)(n.Heading,{as:"h1",size:"lg",mb:4,children:[e.info.icon," ",e.info.name]}),i.jsx(n.Text,{color:"brand.gray.600",mb:6,children:e.info.description}),e.components.detail&&i.jsx(e.components.detail,{})]})})}):i.jsx(o.Z,{children:i.jsx(n.Container,{maxW:"var(--max-width)",py:8,children:i.jsx(n.Text,{children:"未找到该工具"})})})}async function h(){return{paths:[],fallback:!0}}async function u({params:e}){let t=(0,l.uL)(e.id);return t?{props:{tool:t},revalidate:60}:{notFound:!0}}[n,o,l]=c.then?(await c)():c,a()}catch(e){a(e)}})},1219:(e,t,r)=>{"use strict";r.a(e,async(e,a)=>{try{r.d(t,{Z:()=>c});var i=r(997),s=r(6689),n=r(2210),o=r(8974),l=e([n,o]);[n,o]=l.then?(await l)():l;let c=()=>{let[e,t]=(0,s.useState)(""),[r,a]=(0,s.useState)([]),l=(0,n.useToast)();return(0,i.jsxs)(n.VStack,{spacing:6,align:"stretch",children:[(0,i.jsxs)(n.Box,{children:[i.jsx(n.Text,{mb:2,fontSize:"sm",color:"gray.600",children:"在下方输入 Markdown 文本，空行将自动分割为不同的消息"}),i.jsx(n.Textarea,{value:e,onChange:e=>t(e.target.value),placeholder:"输入 Markdown 文本...",minH:"200px",bg:"white"})]}),(0,i.jsxs)(n.HStack,{children:[i.jsx(n.Button,{colorScheme:"blue",onClick:()=>{if(!e.trim()){l({title:"请输入 Markdown 文本",status:"warning",duration:2e3});return}let t=e.split("\n"),r=[],i="";t.forEach(e=>{""===e.trim()?i&&(r.push(i),i=""):i+=e+"\n"}),i&&r.push(i);let s=r.map((e,t)=>({id:t,content:(0,o.marked)(e),type:t%2==0?"sent":"received",timestamp:new Date().toLocaleTimeString("zh-CN",{hour:"2-digit",minute:"2-digit"})}));a(s)},children:"转换"}),r.length>0&&i.jsx(n.Button,{variant:"outline",onClick:()=>{let e=r.map(e=>`
        <div class="chat-message ${e.type}">
          <div class="chat-bubble">
            ${e.content}
          </div>
          <div class="chat-time">${e.timestamp}</div>
        </div>
      `).join(""),t=`
      <style>
        .chat-container {
          max-width: 100%;
          margin: 0 auto;
          padding: 20px;
          font-family: system-ui, -apple-system, sans-serif;
        }
        .chat-message {
          margin: 16px 0;
          display: flex;
          flex-direction: column;
        }
        .chat-message.sent {
          align-items: flex-end;
        }
        .chat-message.received {
          align-items: flex-start;
        }
        .chat-bubble {
          max-width: 70%;
          padding: 12px 16px;
          border-radius: 12px;
          font-size: 15px;
          line-height: 1.5;
        }
        .chat-message.sent .chat-bubble {
          background-color: #95B79D;
          color: #fff;
        }
        .chat-message.received .chat-bubble {
          background-color: #fff;
          border: 1px solid #E5E7EB;
        }
        .chat-time {
          font-size: 12px;
          color: #9CA3AF;
          margin-top: 4px;
        }
      </style>
      <div class="chat-container">
        ${e}
      </div>
    `;navigator.clipboard.writeText(t).then(()=>{l({title:"已复制到剪贴板",status:"success",duration:2e3})})},children:"复制 HTML"})]}),r.length>0&&i.jsx(n.Box,{bg:"gray.50",p:4,borderRadius:"md",maxW:"500px",mx:"auto",w:"100%",children:r.map(e=>(0,i.jsxs)(n.Box,{mb:4,display:"flex",flexDir:"column",alignItems:"sent"===e.type?"flex-end":"flex-start",children:[i.jsx(n.Box,{maxW:"70%",bg:"sent"===e.type?"#95B79D":"white",color:"sent"===e.type?"white":"inherit",p:3,borderRadius:"lg",border:"received"===e.type?"1px solid":"none",borderColor:"gray.200",dangerouslySetInnerHTML:{__html:e.content}}),i.jsx(n.Text,{fontSize:"xs",color:"gray.500",mt:1,children:e.timestamp})]},e.id))})]})};a()}catch(e){a(e)}})},3806:(e,t,r)=>{"use strict";r.a(e,async(e,a)=>{try{r.d(t,{v:()=>l});var i=r(997),s=r(1219),n=r(2210),o=e([s,n]);[s,n]=o.then?(await o)():o;let l={info:{id:"markdown-chat",name:"Markdown 转聊天",description:"将 Markdown 文本转换为微信风格的聊天气泡",icon:"\uD83D\uDCAC",category:"productivity"},routes:{index:"/tools/markdown-chat"},components:{icon:()=>i.jsx(n.Text,{fontSize:"2xl",children:"\uD83D\uDCAC"}),preview:()=>i.jsx(n.Box,{p:4,bg:"white",borderRadius:"md",children:i.jsx(n.Text,{children:"将 Markdown 文本转换为微信风格的聊天气泡"})}),detail:s.Z}};a()}catch(e){a(e)}})},6961:()=>{},2744:()=>{},2785:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/pages.runtime.prod.js")},6689:e=>{"use strict";e.exports=require("react")},6405:e=>{"use strict";e.exports=require("react-dom")},997:e=>{"use strict";e.exports=require("react/jsx-runtime")},2048:e=>{"use strict";e.exports=require("fs")},5315:e=>{"use strict";e.exports=require("path")},6162:e=>{"use strict";e.exports=require("stream")},1568:e=>{"use strict";e.exports=require("zlib")},2210:e=>{"use strict";e.exports=import("@chakra-ui/react")},8974:e=>{"use strict";e.exports=import("marked")}};var t=require("../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[899,910],()=>r(8832));module.exports=a})();